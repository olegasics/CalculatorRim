package ru.operation;

public class Minus extends OperationAbctrsact {


    @Override
    public int Operation(int valueOne, int valueTwo) {
        int result = valueOne - valueTwo;
        return result;
    }


}
