package ru.operation;

public class Description extends OperationAbctrsact  {



    @Override
    public int Operation(int valueOne, int valueTwo) {
        int result = valueOne/valueTwo;
        return result;
    }

}
