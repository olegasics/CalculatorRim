package ru.operation;

public class Multi extends  OperationAbctrsact {



    public int Operation(int valueOne, int valueTwo) {
        int result = valueOne * valueTwo;
        return result;
    }
}
