package Logic;

import ru.operation.Plus;
import ru.operation.Minus;
import ru.operation.Multi;
import ru.operation.Description;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Logic {

    public Logic(String[] array, String arabOrRim) throws Exception {

        Map<String, Integer> map = new HashMap<>();

        map.put("I",1 );
        map.put("II", 2);
        map.put("III", 3);
        map.put("VI", 4);
        map.put("V", 5);
        map.put("VI", 6);
        map.put("VII", 7);
        map.put("VIII", 8);
        map.put("XI", 9);
        map.put("X", 10);


        if (arabOrRim.equals("1")) {

            switch (array[1]) {
                case "+":
                    Plus plus = new Plus();
                    System.out.println("Результат : " + plus.Operation(Integer.parseInt(array[0]), Integer.parseInt(array[2])));
                    break;

                case "-":
                    Minus minus = new Minus();
                    System.out.printf("Результат : " + "%d", minus.Operation(Integer.parseInt(array[0]), Integer.parseInt(array[2])));
                    break;


                case "*":
                    Multi multi = new Multi();
                    System.out.printf("Результат : " + "%d", multi.Operation(Integer.parseInt(array[0]), Integer.parseInt(array[2])));
                    break;

                case "/":
                    Description description = new Description();
                    System.out.printf("Результат : " + "%d", description.Operation(Integer.parseInt(array[0]), Integer.parseInt(array[2])));
                    break;

                default:
                    throw new Exception("Введен неверный арифметический оператор");

            }
        }
        if (arabOrRim.equals("2")) {
            switch (array[1]) {
                case "+":
                    Plus plus = new Plus();
                    if (map.containsKey(array[0]) && map.containsKey(array[2])) {
                        int temp = plus.Operation(map.get(array[0]), map.get(array[2]));
                        Set<Map.Entry<String, Integer>> resultMap = map.entrySet();
                        for (Map.Entry<String, Integer> pair : resultMap) {
                            if (pair.getValue() == temp) {
                                System.out.printf("Результат : " + pair.getKey());
                            }
                        }
                    }

                    break;


            case "-" :
                Minus minus = new Minus();
                if (map.containsKey(array[0]) && map.containsKey(array[2])) {
                    int temp = minus.Operation(map.get(array[0]), map.get(array[2]));
                    Set<Map.Entry<String, Integer>> resultMap = map.entrySet();
                    for (Map.Entry<String, Integer> pair : resultMap) {
                        if (pair.getValue() == temp) {
                            System.out.printf("Результат : " + pair.getKey());
                        }
                    }
                }
                break;


                case "*":
                    Multi multi = new Multi();
                    if (map.containsKey(array[0]) && map.containsKey(array[2])) {
                        int temp = multi.Operation(map.get(array[0]), map.get(array[2]));
                        Set<Map.Entry<String, Integer>> resultMap = map.entrySet();
                        for (Map.Entry<String, Integer> pair : resultMap) {
                            if (pair.getValue() == temp) {
                                System.out.printf("Результат : " + pair.getKey());
                            }
                        }
                    }
                    break;
                case "/":
                    Description description = new Description();
                    if (map.containsKey(array[0]) && map.containsKey(array[2])) {
                        int temp = description.Operation(map.get(array[0]), map.get(array[2]));
                        Set<Map.Entry<String, Integer>> resultMap = map.entrySet();
                        for(Map.Entry<String, Integer> pair : resultMap) {
                            if(pair.getValue() == temp) {
                                System.out.printf("Результат : " +  pair.getKey());
                            }
                        }

                    }
                    break;
                default:
                    throw new Exception("Введен неверный арифметический оператор");
            }

        }
    }
}
