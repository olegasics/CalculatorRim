package Main;

import Logic.Logic;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws Exception {

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Какие цифры вы будете использовать?");
        System.out.println("1.Арабские");
        System.out.println("2.Римские");
                String arabOrRim = in.readLine();
                System.out.println("Введите выражение (цифры от 1 до 10 включительно)");
                String str = in.readLine();
               String[] array = str.split(" ");
               Logic logic = new Logic(array, arabOrRim);




    }

        }

